import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, Target, Zap, Apple, Dumbbell, Clock, Trophy, CheckCircle } from "lucide-react"

export default function SpartanMethodSteps() {
  return (
    <section id="spartan-steps" className="py-16 bg-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <Badge className="mb-6 bg-red-600/20 text-red-400 border-red-600/30">THE COMPLETE SYSTEM</Badge>
          <h2 className="text-4xl font-bold mb-4">The Spartan Method: Step by Step</h2>
          <p className="text-gray-400 max-w-3xl mx-auto text-lg">
            Follow this proven 12-week transformation protocol. Each phase builds upon the last, forging you into the
            warrior you were meant to be.
          </p>
        </div>

        {/* Phase 1: Foundation */}
        <div className="mb-16">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold text-red-400 mb-2">Phase 1: Foundation (Weeks 1-4)</h3>
            <p className="text-gray-300">Build the bedrock of your transformation</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-gradient-to-b from-red-900/20 to-black border-red-900/30">
              <CardHeader>
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mb-4">
                  <span className="text-white font-bold text-lg">1</span>
                </div>
                <CardTitle className="text-white">Mindset Reset</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2 text-sm">
                  <li>• Daily 5 AM wake-up</li>
                  <li>• 10-minute meditation</li>
                  <li>• Goal visualization</li>
                  <li>• Eliminate excuses</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-b from-red-900/20 to-black border-red-900/30">
              <CardHeader>
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mb-4">
                  <span className="text-white font-bold text-lg">2</span>
                </div>
                <CardTitle className="text-white">Movement Basics</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2 text-sm">
                  <li>• Bodyweight squats</li>
                  <li>• Push-ups progression</li>
                  <li>• Plank holds</li>
                  <li>• Walking/jogging</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-b from-red-900/20 to-black border-red-900/30">
              <CardHeader>
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mb-4">
                  <span className="text-white font-bold text-lg">3</span>
                </div>
                <CardTitle className="text-white">Nutrition Cleanup</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2 text-sm">
                  <li>• Eliminate processed foods</li>
                  <li>• 3 whole food meals</li>
                  <li>• Hydration tracking</li>
                  <li>• Meal prep basics</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-b from-red-900/20 to-black border-red-900/30">
              <CardHeader>
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mb-4">
                  <span className="text-white font-bold text-lg">4</span>
                </div>
                <CardTitle className="text-white">Recovery Setup</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2 text-sm">
                  <li>• 7-8 hours sleep</li>
                  <li>• Basic stretching</li>
                  <li>• Stress management</li>
                  <li>• Progress tracking</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Phase 2: Strength */}
        <div className="mb-16">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold text-red-400 mb-2">Phase 2: Strength (Weeks 5-8)</h3>
            <p className="text-gray-300">Build functional power and muscle</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-gradient-to-b from-red-900/20 to-black border-red-900/30">
              <CardHeader>
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mb-4">
                  <span className="text-white font-bold text-lg">5</span>
                </div>
                <CardTitle className="text-white">Compound Lifts</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2 text-sm">
                  <li>• Deadlifts</li>
                  <li>• Squats</li>
                  <li>• Pull-ups</li>
                  <li>• Overhead press</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-b from-red-900/20 to-black border-red-900/30">
              <CardHeader>
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mb-4">
                  <span className="text-white font-bold text-lg">6</span>
                </div>
                <CardTitle className="text-white">Progressive Overload</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2 text-sm">
                  <li>• Weekly weight increases</li>
                  <li>• Rep progression</li>
                  <li>• Form perfection</li>
                  <li>• Strength tracking</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-b from-red-900/20 to-black border-red-900/30">
              <CardHeader>
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mb-4">
                  <span className="text-white font-bold text-lg">7</span>
                </div>
                <CardTitle className="text-white">Protein Focus</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2 text-sm">
                  <li>• 1g per lb bodyweight</li>
                  <li>• Post-workout nutrition</li>
                  <li>• Lean meat sources</li>
                  <li>• Recovery optimization</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-b from-red-900/20 to-black border-red-900/30">
              <CardHeader>
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mb-4">
                  <span className="text-white font-bold text-lg">8</span>
                </div>
                <CardTitle className="text-white">Mental Toughness</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2 text-sm">
                  <li>• Cold showers</li>
                  <li>• Discomfort training</li>
                  <li>• Discipline building</li>
                  <li>• Consistency focus</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Phase 3: Conditioning */}
        <div className="mb-16">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold text-red-400 mb-2">Phase 3: Conditioning (Weeks 9-12)</h3>
            <p className="text-gray-300">Forge elite-level endurance and power</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-gradient-to-b from-red-900/20 to-black border-red-900/30">
              <CardHeader>
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mb-4">
                  <span className="text-white font-bold text-lg">9</span>
                </div>
                <CardTitle className="text-white">HIIT Protocols</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2 text-sm">
                  <li>• Sprint intervals</li>
                  <li>• Burpee circuits</li>
                  <li>• Metabolic finishers</li>
                  <li>• Tabata training</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-b from-red-900/20 to-black border-red-900/30">
              <CardHeader>
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mb-4">
                  <span className="text-white font-bold text-lg">10</span>
                </div>
                <CardTitle className="text-white">Advanced Movements</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2 text-sm">
                  <li>• Olympic lifts</li>
                  <li>• Plyometrics</li>
                  <li>• Complex training</li>
                  <li>• Functional patterns</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-b from-red-900/20 to-black border-red-900/30">
              <CardHeader>
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mb-4">
                  <span className="text-white font-bold text-lg">11</span>
                </div>
                <CardTitle className="text-white">Peak Nutrition</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2 text-sm">
                  <li>• Carb cycling</li>
                  <li>• Intermittent fasting</li>
                  <li>• Supplement timing</li>
                  <li>• Body composition</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-b from-red-900/20 to-black border-red-900/30">
              <CardHeader>
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mb-4">
                  <span className="text-white font-bold text-lg">12</span>
                </div>
                <CardTitle className="text-white">Warrior Mindset</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2 text-sm">
                  <li>• Unbreakable discipline</li>
                  <li>• Pain tolerance</li>
                  <li>• Mental resilience</li>
                  <li>• Spartan identity</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Daily Schedule */}
        <div className="bg-gradient-to-br from-red-900/20 to-black p-8 rounded-lg border border-red-600/30">
          <h3 className="text-2xl font-bold text-red-400 mb-6 text-center">Daily Spartan Schedule</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-xl font-semibold text-white mb-4">Morning Warrior Routine</h4>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                    <Clock className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">5:00 AM - Rise</p>
                    <p className="text-gray-400 text-sm">No snooze, immediate action</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                    <Zap className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">5:05 AM - Cold Shower</p>
                    <p className="text-gray-400 text-sm">Mental toughness activation</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                    <Target className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">5:15 AM - Meditation</p>
                    <p className="text-gray-400 text-sm">10 minutes of focus</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                    <Apple className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">6:00 AM - Nutrition</p>
                    <p className="text-gray-400 text-sm">Warrior fuel preparation</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h4 className="text-xl font-semibold text-white mb-4">Training & Recovery</h4>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                    <Dumbbell className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">7:00 AM - Training</p>
                    <p className="text-gray-400 text-sm">45-60 minutes of intensity</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                    <Apple className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">12:00 PM - Meal 1</p>
                    <p className="text-gray-400 text-sm">Post-workout recovery</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                    <Apple className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">6:00 PM - Meal 2</p>
                    <p className="text-gray-400 text-sm">Evening nutrition</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                    <Shield className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">9:00 PM - Recovery</p>
                    <p className="text-gray-400 text-sm">Prepare for battle tomorrow</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Success Metrics */}
        <div className="mt-16 text-center">
          <h3 className="text-2xl font-bold text-red-400 mb-6">Track Your Transformation</h3>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="bg-black/50 p-6 rounded-lg border border-red-900/30">
              <Trophy className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h4 className="text-white font-semibold mb-2">Strength Gains</h4>
              <p className="text-gray-400 text-sm">Track your lifts weekly</p>
            </div>
            <div className="bg-black/50 p-6 rounded-lg border border-red-900/30">
              <Target className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h4 className="text-white font-semibold mb-2">Body Composition</h4>
              <p className="text-gray-400 text-sm">Photos and measurements</p>
            </div>
            <div className="bg-black/50 p-6 rounded-lg border border-red-900/30">
              <Zap className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h4 className="text-white font-semibold mb-2">Energy Levels</h4>
              <p className="text-gray-400 text-sm">Daily energy rating</p>
            </div>
            <div className="bg-black/50 p-6 rounded-lg border border-red-900/30">
              <CheckCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h4 className="text-white font-semibold mb-2">Consistency</h4>
              <p className="text-gray-400 text-sm">Habit completion rate</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
