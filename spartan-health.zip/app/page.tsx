import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, Sword, Target, Zap, Apple, Dumbbell, Clock, Trophy } from "lucide-react"
import SpartanMethodSteps from "./spartan-method-steps"
;("use client")

export default function SpartanHealthPage() {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    experience: "",
    goals: [],
    motivation: "",
    commitment: "",
  })
  const [isFormSubmitted, setIsFormSubmitted] = useState(false)
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="border-b border-red-900/20 bg-black/50 backdrop-blur-sm fixed w-full z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Shield className="h-8 w-8 text-red-600" />
            <span className="text-xl font-bold">SPARTAN HEALTH</span>
          </div>
          <div className="hidden md:flex space-x-6">
            <a href="#method" className="hover:text-red-400 transition-colors">
              Method
            </a>
            <a href="#nutrition" className="hover:text-red-400 transition-colors">
              Nutrition
            </a>
            <a href="#training" className="hover:text-red-400 transition-colors">
              Training
            </a>
            <a href="#lifestyle" className="hover:text-red-400 transition-colors">
              Lifestyle
            </a>
          </div>
          <Button className="bg-red-600 hover:bg-red-700 text-white">Start Your Journey</Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-20 pb-16 bg-gradient-to-b from-red-900/20 to-black">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <Badge className="mb-6 bg-red-600/20 text-red-400 border-red-600/30">
              DISCIPLINE • SIMPLICITY • STRENGTH
            </Badge>
            <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-white to-red-400 bg-clip-text text-transparent">
              THE SPARTAN METHOD
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-8 leading-relaxed">
              Forge your body and mind through ancient wisdom and modern science. Embrace the warrior's path to optimal
              health and peak performance.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
                <DialogTrigger asChild>
                  <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white px-8 py-3">
                    <Sword className="mr-2 h-5 w-5" />
                    Begin Training
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-black border-red-900/30 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle className="text-2xl font-bold text-center mb-2">
                      <Shield className="inline-block mr-2 h-6 w-6 text-red-500" />
                      Begin Your Spartan Transformation
                    </DialogTitle>
                    <DialogDescription className="text-gray-400 text-center">
                      Take the first step towards becoming the warrior you were meant to be
                    </DialogDescription>
                  </DialogHeader>

                  {!isFormSubmitted ? (
                    <form
                      className="space-y-6 mt-6"
                      onSubmit={(e) => {
                        e.preventDefault()
                        console.log("Form submitted:", formData)
                        setIsFormSubmitted(true)
                      }}
                    >
                      {/* Personal Information */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-red-400">Personal Information</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="name" className="text-white">
                              Full Name *
                            </Label>
                            <Input
                              id="name"
                              required
                              className="bg-gray-900 border-red-900/30 text-white focus:border-red-500"
                              value={formData.name}
                              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label htmlFor="email" className="text-white">
                              Email Address *
                            </Label>
                            <Input
                              id="email"
                              type="email"
                              required
                              className="bg-gray-900 border-red-900/30 text-white focus:border-red-500"
                              value={formData.email}
                              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            />
                          </div>
                        </div>
                      </div>

                      {/* Experience Level */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-red-400">Current Fitness Level</h3>
                        <RadioGroup
                          value={formData.experience}
                          onValueChange={(value) => setFormData({ ...formData, experience: value })}
                          className="space-y-2"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="beginner" id="beginner" className="border-red-500 text-red-500" />
                            <Label htmlFor="beginner" className="text-white">
                              Beginner - New to fitness
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem
                              value="intermediate"
                              id="intermediate"
                              className="border-red-500 text-red-500"
                            />
                            <Label htmlFor="intermediate" className="text-white">
                              Intermediate - Some experience
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="advanced" id="advanced" className="border-red-500 text-red-500" />
                            <Label htmlFor="advanced" className="text-white">
                              Advanced - Experienced athlete
                            </Label>
                          </div>
                        </RadioGroup>
                      </div>

                      {/* Goals */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-red-400">Your Goals (Select all that apply)</h3>
                        <div className="space-y-2">
                          {[
                            "Weight Loss",
                            "Muscle Building",
                            "Strength Training",
                            "Endurance",
                            "Overall Health",
                            "Mental Discipline",
                            "Become Taller",
                          ].map((goal) => (
                            <div key={goal} className="flex items-center space-x-2">
                              <Checkbox
                                id={goal}
                                className="border-red-500 data-[state=checked]:bg-red-600"
                                onCheckedChange={(checked) => {
                                  if (checked) {
                                    setFormData({ ...formData, goals: [...formData.goals, goal] })
                                  } else {
                                    setFormData({ ...formData, goals: formData.goals.filter((g) => g !== goal) })
                                  }
                                }}
                              />
                              <Label htmlFor={goal} className="text-white">
                                {goal}
                              </Label>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Motivation */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-red-400">What Drives You?</h3>
                        <Textarea
                          placeholder="Tell us what motivates you to start this transformation..."
                          className="bg-gray-900 border-red-900/30 text-white focus:border-red-500 min-h-[100px]"
                          value={formData.motivation}
                          onChange={(e) => setFormData({ ...formData, motivation: e.target.value })}
                        />
                      </div>

                      {/* Commitment Level */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-red-400">Training Commitment</h3>
                        <RadioGroup
                          value={formData.commitment}
                          onValueChange={(value) => setFormData({ ...formData, commitment: value })}
                          className="space-y-2"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="3-days" id="3-days" className="border-red-500 text-red-500" />
                            <Label htmlFor="3-days" className="text-white">
                              3 days per week
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="4-days" id="4-days" className="border-red-500 text-red-500" />
                            <Label htmlFor="4-days" className="text-white">
                              4-5 days per week
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="6-days" id="6-days" className="border-red-500 text-red-500" />
                            <Label htmlFor="6-days" className="text-white">
                              6+ days per week (Spartan Mode)
                            </Label>
                          </div>
                        </RadioGroup>
                      </div>

                      {/* Submit Button */}
                      <div className="pt-4">
                        <Button
                          type="submit"
                          className="w-full bg-red-600 hover:bg-red-700 text-white py-3 text-lg font-semibold"
                        >
                          <Trophy className="mr-2 h-5 w-5" />
                          Begin My Spartan Journey
                        </Button>
                        <p className="text-xs text-gray-400 text-center mt-2">
                          By submitting, you agree to receive communications about your Spartan transformation journey.
                        </p>
                      </div>
                    </form>
                  ) : (
                    <div className="space-y-6 mt-6">
                      <div className="text-center mb-6">
                        <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                          <Trophy className="h-8 w-8 text-white" />
                        </div>
                        <h3 className="text-2xl font-bold text-white mb-2">
                          Welcome to the Brotherhood, {formData.name}!
                        </h3>
                        <p className="text-gray-400">Your personalized Spartan method is ready</p>
                      </div>

                      <div className="bg-gradient-to-br from-red-900/20 to-black p-6 rounded-lg border border-red-600/30">
                        <h4 className="text-xl font-bold text-red-400 mb-4">Your Spartan Protocol</h4>

                        <div className="space-y-4">
                          <div className="bg-black/50 p-4 rounded border-l-4 border-red-600">
                            <h5 className="font-semibold text-white mb-2">Fitness Level: {formData.experience}</h5>
                            <p className="text-gray-300 text-sm">
                              {formData.experience === "beginner" &&
                                "Start with bodyweight exercises and basic compound movements. Focus on form and consistency."}
                              {formData.experience === "intermediate" &&
                                "Incorporate progressive overload with compound lifts. Add metabolic conditioning."}
                              {formData.experience === "advanced" &&
                                "Advanced training protocols with heavy compound lifts and intense conditioning circuits."}
                            </p>
                          </div>

                          <div className="bg-black/50 p-4 rounded border-l-4 border-red-600">
                            <h5 className="font-semibold text-white mb-2">Training Schedule: {formData.commitment}</h5>
                            <p className="text-gray-300 text-sm">
                              {formData.commitment === "3-days" &&
                                "3 full-body sessions per week with active recovery days."}
                              {formData.commitment === "4-days" && "Upper/lower split with cardio and mobility work."}
                              {formData.commitment === "6-days" &&
                                "Push/pull/legs split with daily conditioning. True Spartan dedication!"}
                            </p>
                          </div>

                          {formData.goals.length > 0 && (
                            <div className="bg-black/50 p-4 rounded border-l-4 border-red-600">
                              <h5 className="font-semibold text-white mb-2">Primary Goals:</h5>
                              <ul className="text-gray-300 text-sm space-y-1">
                                {formData.goals.map((goal, index) => (
                                  <li key={index}>• {goal}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          <div className="bg-black/50 p-4 rounded border-l-4 border-red-600">
                            <h5 className="font-semibold text-white mb-3">Your Exercise Demonstrations</h5>
                            <div className="mb-3">
                              <img
                                src="/placeholder.svg?height=200&width=300"
                                alt="Spartan workout exercises demonstration"
                                className="w-full h-48 object-cover rounded border border-red-600/30"
                              />
                            </div>
                            <p className="text-gray-300 text-sm">
                              Master these fundamental Spartan movements: Squats, Push-ups, Pull-ups, and Planks. Form
                              is everything - quality over quantity, warrior.
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-gradient-to-br from-red-900/20 to-black p-6 rounded-lg border border-red-600/30">
                        <h4 className="text-xl font-bold text-red-400 mb-4">Your First Week</h4>
                        <div className="space-y-3">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center text-white text-sm font-bold">
                              1
                            </div>
                            <div>
                              <p className="text-white font-semibold">Nutrition Assessment</p>
                              <p className="text-gray-400 text-sm">Track your current eating habits for 3 days</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center text-white text-sm font-bold">
                              2
                            </div>
                            <div>
                              <p className="text-white font-semibold">Movement Assessment</p>
                              <p className="text-gray-400 text-sm">Complete basic movement screen and fitness test</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center text-white text-sm font-bold">
                              3
                            </div>
                            <div>
                              <p className="text-white font-semibold">First Training Session</p>
                              <p className="text-gray-400 text-sm">Begin with your personalized workout plan</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <Button
                          className="w-full bg-red-600 hover:bg-red-700 text-white py-3"
                          onClick={() => {
                            setIsModalOpen(false)
                            setIsFormSubmitted(false)
                            setFormData({
                              name: "",
                              email: "",
                              experience: "",
                              goals: [],
                              motivation: "",
                              commitment: "",
                            })
                            // Scroll to the method section
                            document.getElementById("method")?.scrollIntoView({ behavior: "smooth" })
                          }}
                        >
                          <Shield className="mr-2 h-5 w-5" />
                          Begin My Spartan Journey
                        </Button>
                        <p className="text-xs text-gray-400 text-center">
                          Check your email for detailed workout plans and nutrition guidelines.
                        </p>
                      </div>
                    </div>
                  )}
                </DialogContent>
              </Dialog>
              <Button
                size="lg"
                variant="outline"
                className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white px-8 py-3"
              >
                Learn the Method
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Core Principles */}
      <section id="method" className="py-16 bg-gray-900/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">The Spartan Principles</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Built on the foundation of ancient warrior wisdom, refined by modern nutritional science
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-black/50 border-red-900/30 hover:border-red-600/50 transition-colors">
              <CardHeader>
                <Target className="h-12 w-12 text-red-500 mb-4" />
                <CardTitle className="text-white">Precision Nutrition</CardTitle>
                <CardDescription className="text-gray-400">
                  Every meal serves a purpose. No wasted calories, maximum impact.
                </CardDescription>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2">
                  <li>• Whole, unprocessed foods only</li>
                  <li>• Strategic meal timing</li>
                  <li>• Nutrient density over quantity</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-black/50 border-red-900/30 hover:border-red-600/50 transition-colors">
              <CardHeader>
                <Zap className="h-12 w-12 text-red-500 mb-4" />
                <CardTitle className="text-white">Mental Fortitude</CardTitle>
                <CardDescription className="text-gray-400">
                  Discipline your mind to control your body and achieve your goals.
                </CardDescription>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2">
                  <li>• Mindful eating practices</li>
                  <li>• Resistance to temptation</li>
                  <li>• Long-term vision focus</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-black/50 border-red-900/30 hover:border-red-600/50 transition-colors">
              <CardHeader>
                <Shield className="h-12 w-12 text-red-500 mb-4" />
                <CardTitle className="text-white">Functional Strength</CardTitle>
                <CardDescription className="text-gray-400">
                  Build a body that performs as well as it looks.
                </CardDescription>
              </CardHeader>
              <CardContent className="text-gray-300">
                <ul className="space-y-2">
                  <li>• Compound movements</li>
                  <li>• Progressive overload</li>
                  <li>• Recovery optimization</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Spartan Method Steps */}
      <SpartanMethodSteps />

      {/* Nutrition Section */}
      <section id="nutrition" className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6">Spartan Nutrition Protocol</h2>
              <p className="text-gray-300 text-lg mb-8">
                Fuel your body like the warrior you are. Our nutrition approach eliminates the unnecessary and amplifies
                what truly matters for peak performance and optimal health.
              </p>

              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <Apple className="h-6 w-6 text-red-500 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-white mb-2">Whole Food Foundation</h3>
                    <p className="text-gray-400">
                      Lean proteins, complex carbohydrates, healthy fats, and abundant vegetables form the core of every
                      meal.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Clock className="h-6 w-6 text-red-500 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-white mb-2">Strategic Timing</h3>
                    <p className="text-gray-400">
                      Intermittent fasting windows and pre/post-workout nutrition to maximize performance and recovery.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Target className="h-6 w-6 text-red-500 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-white mb-2">Precision Macros</h3>
                    <p className="text-gray-400">
                      Calculated protein, carbohydrate, and fat ratios tailored to your training goals and body
                      composition.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-red-900/20 to-black p-8 rounded-lg border border-red-900/30">
              <h3 className="text-2xl font-bold mb-6 text-center">Daily Spartan Meal Plan</h3>
              <div className="space-y-4">
                <div className="bg-black/50 p-4 rounded border-l-4 border-red-600">
                  <h4 className="font-semibold text-red-400">Morning (6:00 AM)</h4>
                  <p className="text-gray-300">Black coffee + 20-minute walk</p>
                </div>
                <div className="bg-black/50 p-4 rounded border-l-4 border-red-600">
                  <h4 className="font-semibold text-red-400">Meal 1 (12:00 PM)</h4>
                  <p className="text-gray-300">Grilled chicken, quinoa, roasted vegetables</p>
                </div>
                <div className="bg-black/50 p-4 rounded border-l-4 border-red-600">
                  <h4 className="font-semibold text-red-400">Pre-Workout (4:00 PM)</h4>
                  <p className="text-gray-300">Greek yogurt with berries</p>
                </div>
                <div className="bg-black/50 p-4 rounded border-l-4 border-red-600">
                  <h4 className="font-semibold text-red-400">Post-Workout (7:00 PM)</h4>
                  <p className="text-gray-300">Salmon, sweet potato, spinach salad</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Training Section */}
      <section id="training" className="py-16 bg-gray-900/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Spartan Training Philosophy</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Train like your life depends on it. Every session builds not just muscle, but character.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-black/50 border-red-900/30 text-center">
              <CardHeader>
                <Dumbbell className="h-12 w-12 text-red-500 mx-auto mb-4" />
                <CardTitle className="text-white">Strength</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">Compound lifts, progressive overload, functional power</p>
              </CardContent>
            </Card>

            <Card className="bg-black/50 border-red-900/30 text-center">
              <CardHeader>
                <Zap className="h-12 w-12 text-red-500 mx-auto mb-4" />
                <CardTitle className="text-white">Conditioning</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">HIIT, metabolic circuits, cardiovascular endurance</p>
              </CardContent>
            </Card>

            <Card className="bg-black/50 border-red-900/30 text-center">
              <CardHeader>
                <Target className="h-12 w-12 text-red-500 mx-auto mb-4" />
                <CardTitle className="text-white">Mobility</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">Dynamic warm-ups, flexibility, injury prevention</p>
              </CardContent>
            </Card>

            <Card className="bg-black/50 border-red-900/30 text-center">
              <CardHeader>
                <Trophy className="h-12 w-12 text-red-500 mx-auto mb-4" />
                <CardTitle className="text-white">Recovery</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">Sleep optimization, active rest, stress management</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Lifestyle Section */}
      <section id="lifestyle" className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-bold mb-6">The Spartan Lifestyle</h2>
            <p className="text-xl text-gray-300 mb-12">
              True transformation happens when discipline becomes a way of life, not just a temporary effort.
            </p>

            <div className="grid md:grid-cols-3 gap-8 text-left">
              <div className="bg-gradient-to-b from-red-900/20 to-black p-6 rounded-lg border border-red-900/30">
                <h3 className="text-xl font-bold mb-4 text-red-400">Morning Rituals</h3>
                <ul className="space-y-2 text-gray-300">
                  <li>• 5:30 AM wake-up</li>
                  <li>• Cold shower</li>
                  <li>• Meditation/breathing</li>
                  <li>• Goal visualization</li>
                </ul>
              </div>

              <div className="bg-gradient-to-b from-red-900/20 to-black p-6 rounded-lg border border-red-900/30">
                <h3 className="text-xl font-bold mb-4 text-red-400">Daily Discipline</h3>
                <ul className="space-y-2 text-gray-300">
                  <li>• Meal prep consistency</li>
                  <li>• Training non-negotiable</li>
                  <li>• Hydration tracking</li>
                  <li>• Progress monitoring</li>
                </ul>
              </div>

              <div className="bg-gradient-to-b from-red-900/20 to-black p-6 rounded-lg border border-red-900/30">
                <h3 className="text-xl font-bold mb-4 text-red-400">Evening Recovery</h3>
                <ul className="space-y-2 text-gray-300">
                  <li>• Digital sunset</li>
                  <li>• Reflection journal</li>
                  <li>• Stretching routine</li>
                  <li>• 8-hour sleep target</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-red-900/30 to-black">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Embrace the Spartan Way?</h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Join thousands who have transformed their bodies and minds through the power of disciplined nutrition and
            training.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
              <DialogTrigger asChild>
                <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white px-8 py-3">
                  <Shield className="mr-2 h-5 w-5" />
                  Start Your Transformation
                </Button>
              </DialogTrigger>
            </Dialog>
            <Button
              size="lg"
              variant="outline"
              className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white px-8 py-3"
            >
              Download Free Guide
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-red-900/20">
        <div className="container mx-auto px-4 text-center text-gray-400">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Shield className="h-6 w-6 text-red-600" />
            <span className="font-bold text-white">SPARTAN HEALTH</span>
          </div>
          <p>© 2024 Spartan Health. Forge your destiny through discipline.</p>
        </div>
      </footer>
    </div>
  )
}
